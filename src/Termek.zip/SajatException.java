public class SajatException extends RuntimeException {
    public SajatException() {
    }

    public SajatException(String message) {
        super(message);
    }
}
