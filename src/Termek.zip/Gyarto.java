public interface Gyarto {
    public boolean gyart();
    public void alapanyagVasarlas(String alapanyag);
}
