public interface KozosInteface {
    public int getPenz();
    public void penztKolt(int mennyit);
}
