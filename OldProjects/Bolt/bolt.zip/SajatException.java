public class SajatException extends RuntimeException  {

    public SajatException() {
        super();
    }

    public SajatException(String message) {
        super(message);
    }
}
