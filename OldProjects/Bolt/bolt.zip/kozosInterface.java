public interface kozosInterface {
    public void penztKolt(int mennyit) throws SajatException;
    public int getPenz();
}
