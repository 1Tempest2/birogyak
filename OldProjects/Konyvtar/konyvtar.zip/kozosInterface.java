public interface kozosInterface {
    public void konyvVetel(String cim);
    public int konyvMennyiseg();
}
